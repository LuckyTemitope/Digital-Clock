// function combine(n1: string | number, n2: number | string) {
//     let result;
    
//     if (typeof n1 === 'number' && typeof n2 === 'number') {
//         result = n1 + n2;
//     } else {
//         result = `${n1} and ${n2}`;
//     }
    
//     return result;
// }

function combine(n1: number, n2: number) {
    let   result = n1 + n2;
    return result;
}

const combineAges = combine(30, 32);
console.log(combineAges);

// const combineNames = combine("Max", "Sam");
// console.log(combineNames);

// let combineValues : Function;
let combineValues : (a: number, b: number) =>  number;
combineValues = combine;
console.log(combineValues(23, 2)); 


function addAndHandle(n1: number, n2: number, cb: (num: number) => void) {
    const result = n1 + n2;
    cb(result);
}