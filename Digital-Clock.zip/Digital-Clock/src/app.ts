const currentDate = new Date();
let hour = currentDate.getHours();

const button = document.querySelector('button')!;

// button.addEventListener('click', () => {
//     console.log(`The current hour is ${hour}`);
// })

let hourGreeting = "";
let hourSuffix = ""

if (hour < 12) {
    hourGreeting = "Morning"
} else if (hour >= 12 && hour < 16) {
    hourGreeting = "Afternoon"
} else {
    hourGreeting = "Evening"
}

if (hour < 12) {
    hourSuffix = "am";
} else {
    hourSuffix = "pm";
}

const greeting = `Good ${hourGreeting}. Welcome back.`;
const timestamp = `${currentDate.getHours()}:${currentDate.getMinutes()}:${currentDate.getSeconds()}${hourSuffix}`;



document.getElementById("greetings")!.innerHTML = greeting;
document.getElementById("timestamp")!.innerHTML = timestamp;


function currentHour() : void {
    console.log(`Good ${hourGreeting}. Welcome back.`);
    console.log(`The current time is ${currentDate.getHours()}:${currentDate.getMinutes()}${hourSuffix}`)
}

