// const person = {
//   name: "John",
//   age: 34,
//   nickname: "JohnyJoe",
//   hobbies: ["Sports", "Movies", "Games", "Music"],
//   role: Role.ADMIN;
// };

// let person : {
//     name: string;
//     age: number;
//     nickname: string;
//     role: [number, string];
// }

enum Role { ADMIN, READ_ONLY, AUTHOR}

const person = {
    name: "John",
    age: 34,
    nickname: "JohnyJoe",
    hobbies: ["Sports", "Movies", "Games", "Music"],
    role: Role.ADMIN
  };
  

let favoriteActivities: string[];
favoriteActivities = ["Sport"];

let listOfFavourites: string[];
listOfFavourites = ["Sport", "Education"];

console.log(person.name);
console.log(person.nickname);
// console.log(person.hobbies);

for (let hobby of person.hobbies) {
  console.log(hobby.toUpperCase());
}

switch (person.role) {
    case Role.ADMIN:
        console.log("Hi, Admin")
        break;
    case Role.AUTHOR:
        console.log("Hi, Author")
        break;
    case Role.READ_ONLY:
        console.log("Hi, User")
        break;        
}